import numpy as np

def solve(numpyArray):
    return numpyArray.sort()