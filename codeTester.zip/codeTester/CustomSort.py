# CustomSort

def bubble_sort(tab):  
    # Outer loop for traverse the entire list  
    for i in range(0,len(tab)-1):  
        for j in range(len(tab)-1):  
            if(tab[j]>tab[j+1]):  
                temp = tab[j]  
                tab[j] = tab[j+1]  
                tab[j+1] = temp  
    return tab  


def mergeSort(tab):
    if len(tab) > 1:         
        mid = len(tab)//2  # Finding the mid of the array      
        left = tab[:mid]  ;  right = tab[mid:] # Dividing the array element       
        mergeSort(left)  ;  mergeSort(right)  # Sorting the first and second half  

        i = j = k = 0
        # Copy data to temp arrays left[] and right[]
        while i < len(left) and j < len(right):
            if left[i][2] <= right[j][2]:
                tab[k] = left[i]
                i += 1
            else:
                tab[k] = right[j]
                j += 1
            k += 1  
        # Checking if any element was left
        while i < len(left):
            tab[k] = left[i]
            i += 1
            k += 1  
        while j < len(right):
            tab[k] = right[j]
            j += 1
            k += 1           
    return tab

def solve(tab):
    return bubble_sort(tab)