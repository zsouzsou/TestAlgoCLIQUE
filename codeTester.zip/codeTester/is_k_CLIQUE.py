import numpy as np
import os

def tmpData():

    def readFile(path):
        return open(path, 'rb').read().decode('utf-8')

    def findPath(fileName):
        #cwd is current working directory (this file.py current folder)
        currentDirectory = os.getcwd() 
        filePath = os.path.join(currentDirectory, fileName)
        return filePath

    def StringToListString(string, split_car):
        amount = 0    # count the number of split_car
        for car in string:
            if car == split_car: amount+=1
        string_split = [0]*amount
        string_split = string.split(split_car)
        return string_split

    def createMatrixFromFile(filePath):
        fileString = readFile(findPath(filePath))
        fileList = StringToListString(fileString, "\r\n")
        N=len(fileList)
        Matrix = np.zeros((N, N), dtype=int)
        for i in range(len(fileList)): 
            fileList[i] = StringToListString(fileList[i], ",")
            for j in range(len(fileList)): 
                Matrix[i][j] = int(fileList[i][j])
        return Matrix

    #Matrix = createMatrixFromFile("size5_5CLIQUE.txt")
    #Matrix = createMatrixFromFile("size6_5CLIQUE.txt")
    #Matrix = createMatrixFromFile("size9_5CLIQUE.txt")
    #Matrix = createMatrixFromFile("size9_NOT_5CLIQUE.txt")
    #Matrix = createMatrixFromFile("size9_NOT_5CLIQUE_few.txt")
    Matrix = createMatrixFromFile("size10_5CLIQUE.txt")          #-----------CLIQUE should be node[5,7,2,6,8]------#
    #Matrix = createMatrixFromFile("size20_NOT_5CLIQUE.txt")

    return Matrix


def isBidirection(Adj_Matrix_Graph):
    # Verify if every vertex is in both direct. If triangle supp == trinangle infer of matrix
    isBidirection = True
    N = len(Adj_Matrix_Graph[0])
    for i in range(N):
        for j in range(N):
            if Adj_Matrix_Graph[i][j] != Adj_Matrix_Graph[j][i]:
                print("Node ",i," and Node ",j,"are not connected in both direction!")
                isBidirection = False
    return isBidirection

def list_Node_With_Enough_Vertex(Adj_Matrix_Graph, numberVertex):
    # find which nodes have at least <numberVertex> attach to it. Return a booleanList
    validNode = [False]*len(Adj_Matrix_Graph[0])
    for i in range(len(Adj_Matrix_Graph)):
        sum = 0
        for element in Adj_Matrix_Graph[i]:
            sum+=element
        # if you search for a 5-CLIQUE, you want at least 4-Vertex on your nodes
        if sum >= numberVertex-1:
            validNode[i] = True
    return validNode


def is5CLIQUE(Adj_Matrix_Graph):
    is5CLIQUE = False
    if (not isBidirection(Adj_Matrix_Graph)):
        print("not bidirectionnel Graph!")
        return is5CLIQUE

    validNode = list_Node_With_Enough_Vertex(Adj_Matrix_Graph,5)
    nodeInCLIQUE = []

    for i in range(0, len(validNode)-4):
      if is5CLIQUE: break #to stop looping if we find a solution

      if validNode[i]:
        for j in range(i+1, len(validNode)-3):
          if validNode[j]:
            for k in range(j+1, len(validNode)-2):
              if validNode[k]:
                for l in range(k+1, len(validNode)-1):
                  if validNode[l]:
                    for m in range(l+1, len(validNode)):
                      if validNode[m]:
                        is5CLIQUE = True
                        nodeInCLIQUE.append(i)
                        nodeInCLIQUE.append(j)
                        nodeInCLIQUE.append(k)
                        nodeInCLIQUE.append(l)
                        nodeInCLIQUE.append(m)

                        if (len(nodeInCLIQUE) != 0): 
                            print("We found a CLIQUE with these nodes:", nodeInCLIQUE)         
                        return is5CLIQUE
    return is5CLIQUE



# ------- for now I roll it in the global --------- #

Adj_Matrix_Graph = tmpData()
print(Adj_Matrix_Graph)
validNode = list_Node_With_Enough_Vertex(Adj_Matrix_Graph, 5)
print(validNode)

answer = is5CLIQUE(Adj_Matrix_Graph)
print("is it clique??? -->" + str(answer))


# --------------------------------------------------- #



def solve(Adj_Matrix_Graph):

    # Im gonna place it in this function when it work (at the end)

    return Adj_Matrix_Graph

#solve()
