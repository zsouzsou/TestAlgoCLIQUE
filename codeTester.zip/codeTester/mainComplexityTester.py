import numpy as np
import matplotlib.pyplot as plt
import time
import os


def readFile(path):
  return open(path, 'rb').read().decode('utf-8')

def writeFile(path, texte):
  file = open(path, 'wb')
  file.write(texte.encode('utf-8'))
  file.close()
  
def findPath(fileName):
    #cwd is current working directory (this file.py current folder)
    currentDirectory = os.getcwd() 
    filePath = os.path.join(currentDirectory, fileName)
    return filePath

def StringToListString(string, split_car):
    amount = 0    # count the number of split_car
    for car in string:
        if car == split_car: amount+=1
    string_split = [0]*amount
    string_split = string.split(split_car)
    return string_split

def createMatrixFromFile(filePath):
   
    fileString = readFile(findPath(filePath))
    fileList = StringToListString(fileString, "\r\n")
    N=len(fileList)
    Matrix = np.zeros((N, N), dtype=int)

    for i in range(len(fileList)): 
       fileList[i] = StringToListString(fileList[i], ",")
       for j in range(len(fileList)): 
          Matrix[i][j] = int(fileList[i][j])

    return Matrix



def createInput(degree=2, test=False, testSize=[]):
   # lunching the function empty will give a custom input (else case)
   dataInput = []

   if test:
       
       if degree == 1:
        for sizeInt in testSize:
           tab = np.linspace(1,sizeInt,sizeInt)
           np.random.shuffle(tab)
           dataInput.append(tab)

       if degree == 2:
        adj5_Matrix = createMatrixFromFile("size5_5CLIQUE.txt")
        adj9_Matrix = createMatrixFromFile("size9_5CLIQUE.txt")
        adj9_NOT_Matrix = createMatrixFromFile("size9_NOT_5CLIQUE.txt")
        adj20_NOT_Matrix = createMatrixFromFile("size20_NOT_5CLIQUE.txt")
        dataInput.append(adj5_Matrix)
        dataInput.append(adj9_Matrix)
        dataInput.append(adj9_NOT_Matrix)
        dataInput.append(adj20_NOT_Matrix)

       return dataInput

   else:
       # ------ initiate custom data input ----- # 


       #<-------------------------------------- write here (setup your input)


       #-----------------------------------------#

       return dataInput

def findTime1Algo(AlgoToTestObject, tabInput, doesItPrint=True):
    timeList = []

    number_of_test = len(tabInput)
    for testNumber in range(number_of_test):
       
       start_time = time.time()

       AlgoToTestObject.solve(tabInput[testNumber])   #<----- maybe change .solve()

       end_time = time.time()  
       duration_time = round(end_time - start_time, 4)
       timeList.append(duration_time)

       if doesItPrint:
        print("\nThe test #"+str(testNumber+1)+" work successfully!")
        print("it took about "+str(duration_time)+" sec to complete the test")#1unit != 1sec
        #print("For input = \n", testInput[testNumber])

    #print("\nThe time for every test was : ", timeList)
    return timeList

def showTimeGraph( timeList1=[],timeList2=[] ):

    if len(timeList1) != 0:
        #plt.plot( data_tab1, data_tab2, 'solid', color='r')  #solid --> '--'
        plt.plot( np.linspace(1, len(timeList1),len(timeList1)) , timeList1)

    if len(timeList2) != 0:
        #plt.plot( data_tab1, data_tab2, 'solid', color='r')  #solid --> '--'
        plt.plot( np.linspace(1, len(timeList2),len(timeList2)) , timeList2)

    if len(timeList1) != 0 or len(timeList2) != 0:
        plt.xlabel("Test#")
        plt.ylabel("Time") 
        plt.title('Distribution of time of different input size (for algorithm)')
        #plt.xscale('log')
        #plt.yscale('log')
        #plt.legend()
        plt.grid()
        plt.show()

    if len(timeList1) != 0 and len(timeList2) != 0:
       for i in len(timeList1):
          print("it took Algo1 a time of"+str(timeList1[i])+"sec and Algo2 a time of"+str(timeList2[i]))
    pass


def main():
   
    # -------------- Write your code to test here -------------------- #

      # --- initiate input --- # 

    startSize = 4000
    endSize = 16000
    step = 4000

    start_time = time.time()

    #optionnal, make sure its int()
    testSize = np.arange(startSize, endSize, step).tolist() 

    #for custom output write "tabInput = createInput()"
    dataInput = createInput(True,1, testSize)#<--------------- make sure that you setup your input properly in the function!!!

    end_time = time.time()  
    duration_time = round(end_time - start_time, 4)
    print("duration to setup the input is about "+str(duration_time)+"sec")
    
      # --- lunch the code --- # 

    #import classAlgo
    import CustomSort #<--------------------------- write here
    import NumpySortFunction

    #AlgoToTest = classObjectAlgo
    AlgoToTest1 = CustomSort #<--------------------- write here, make sure it use .solve() method or change it above
    AlgoToTest2 = NumpySortFunction

    # ----------------------------------------------------------------- #

    timeList1 = []   ; timeList2 = []
    timeList1 = findTime1Algo(AlgoToTest1, dataInput)
    timeList2 = findTime1Algo(AlgoToTest2, dataInput)

    showTimeGraph(timeList1, timeList2)

    pass


if __name__ == "__main__":
    main()